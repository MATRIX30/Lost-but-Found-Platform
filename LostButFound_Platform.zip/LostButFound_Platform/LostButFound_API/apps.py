from django.apps import AppConfig


class LostbutfoundApiConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'LostButFound_API'
